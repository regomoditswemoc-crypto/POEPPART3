/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poep2;


import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;

public class Message {
    
    // ===== VARIABLES =====
    public String messageID;
    public String messageHash;
    public String recipient;
    public String messageText;
    public boolean isSent;
    public boolean isStored;
    
    public static int totalMessages = 0;
    
    // ===== CONSTRUCTOR =====
    public Message() {
        messageID = "";
        messageHash = "";
        recipient = "";
        messageText = "";
        isSent = false;
        isStored = false;
    }
    
    // ===== CHECK MESSAGE ID (max 10 characters) =====
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }
    
    // ===== CHECK RECIPIENT CELLPHONE NUMBER =====
    public String checkRecipientCell() {
        if (recipient.length() <= 10 && (recipient.startsWith("+") || recipient.startsWith("0"))) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted. Please correct and try again.";
        }
    }
    
    // ===== CREATE MESSAGE HASH =====
    public String createMessageHash() {
        String firstTwo = messageID.substring(0, 2);
        String[] words = messageText.split(" ");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        messageHash = firstTwo + ":" + firstWord.toUpperCase() + lastWord.toUpperCase();
        return messageHash;
    }
    
    // ===== SEND MESSAGE =====
    public String SentMessage() {
        if (messageText.length() > 250) {
            int extra = messageText.length() - 250;
            return "Message exceeds 250 characters by " + extra + "; please reduce the size.";
        } else {
            isSent = true;
            totalMessages++;
            return "Message successfully sent.";
        }
    }
    
    // ===== STORE MESSAGE =====
    public String storeMessage() {
        isStored = true;
        totalMessages++;
        return "Message successfully stored.";
    }
    
    // ===== GENERATE RANDOM ID =====
    public void generateID() {
        Random rand = new Random();
        String temp = "";
        for (int i = 0; i < 10; i++) {
            temp += rand.nextInt(10);
        }
        messageID = temp;
    }
    
    // ===== SAVE TO JSON FILE =====
    public void saveToFile() {
        try (FileWriter writer = new FileWriter("messages.json", true)) {
            writer.write(toJSON() + "\n");
        } catch (IOException e) {
            System.out.println("Error saving message to file.");
        }
    }
    
    // ===== CONVERT TO JSON FORMAT =====
    public String toJSON() {
        return "{\"messageID\":\"" + messageID + "\", " +
               "\"messageHash\":\"" + messageHash + "\", " +
               "\"recipient\":\"" + recipient + "\", " +
               "\"message\":\"" + messageText + "\"}";
    }
    
    // ===== PRINT ALL MESSAGES =====
    public String printMessages() {
        return "ID: " + messageID + "\nHash: " + messageHash + "\nRecipient: " + recipient + "\nMessage: " + messageText;
    }
    
    // ===== RETURN TOTAL MESSAGES =====
    public int returnTotalMessages() {
        return totalMessages;
    }
}