/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poep2;
import java.util.Scanner;
/**
 *
 * @author EUNICE
 */
public class StoredMenu {
    
    private static Scanner input = new Scanner(System.in);
    
    public static void showMenu() {
        String choice;
        
        while (true) {
            System.out.println("\n+--------------------------------------------------+");
            System.out.println("|              STORED MESSAGES MENU                 |");
            System.out.println("+--------------------------------------------------+");
            System.out.println("|  a. Display ALL stored messages                  |");
            System.out.println("|  b. Display the LONGEST stored message           |");
            System.out.println("|  c. SEARCH for a message by ID                   |");
            System.out.println("|  d. SEARCH for messages by recipient             |");
            System.out.println("|  e. DELETE a message using its hash              |");
            System.out.println("|  f. Display FULL REPORT                         |");
            System.out.println("|  g. Return to MAIN MENU                         |");
            System.out.println("+--------------------------------------------------+");
            System.out.print("Enter your choice (a-g): ");
            
            choice = input.nextLine().toLowerCase();
            
            switch (choice) {
                case "a":
                    MessagePart3.showAllStored();
                    break;
                    
                case "b":
                    System.out.println("\n>>> LONGEST STORED MESSAGE <<<");
                    System.out.println(MessagePart3.findLongest());
                    break;
                    
                case "c":
                    System.out.print("\nEnter Message ID: ");
                    System.out.println(MessagePart3.searchByID(input.nextLine()));
                    break;
                    
                case "d":
                    System.out.print("\nEnter Recipient: ");
                    String rec = input.nextLine();
                    String[] results = MessagePart3.searchByRecipient(rec);
                    
                    if (results.length == 0) {
                        System.out.println("No messages found for: " + rec);
                    } else {
                        System.out.println("\nFound " + results.length + " message(s):");
                        for (String r : results) {
                            System.out.println(r);
                        }
                    }
                    break;
                    
                case "e":
                    System.out.print("\nEnter Message Hash to delete: ");
                    MessagePart3.deleteByHash(input.nextLine());
                    break;
                    
                case "f":
                    MessagePart3.showFullReport();
                    break;
                    
                case "g":
                    System.out.println("\nReturning to Main Menu...");
                    return;
                    
                default:
                    System.out.println("\nInvalid choice! Please enter a-g.");
            }
        }
    }
}
    

