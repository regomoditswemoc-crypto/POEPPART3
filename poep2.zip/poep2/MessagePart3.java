/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poep2;
import java.io.*;
import java.nio.file.*;
/**
 *
 * @author EUNICE
 */
public class MessagePart3{
   
    
    // ===== FIVE ARRAYS AS REQUIRED BY RUBRIC =====
    public static String[] sentMessages = new String[100];
    public static String[] disregardedMessages = new String[100];
    public static String[] storedMessages = new String[100];
    public static String[] messageHashes = new String[100];
    public static String[] messageIDs = new String[100];
    
    // ===== COUNTERS =====
    public static int sentCount = 0;
    public static int disregardedCount = 0;
    public static int storedCount = 0;

    static void loadTestData() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    // ===== SINGLE MESSAGE VARIABLES =====
    private String sender;
    private String recipient;
    private String messageText;
    private String flag;
    private String msgHash;
    private String msgID;
    
    // ===== CONSTRUCTOR =====
    public MessagePart3(String s, String r, String m, String f) {
        sender = s;
        recipient = r;
        messageText = m;
        flag = f;
        msgID = generateID();
        msgHash = generateHash();
    }
    
    // ===== GENERATE UNIQUE ID =====
    private String generateID() {
        return "MID" + System.currentTimeMillis();
    }
    
    // ===== GENERATE UNIQUE HASH =====
    private String generateHash() {
        String all = sender + recipient + messageText;
        return Integer.toHexString(all.hashCode());
    }
    
    // ===== SAVE MESSAGE TO CORRECT ARRAY BASED ON FLAG =====
    public void saveMessage() {
        String displayLine = "From: " + sender + " | To: " + recipient + " | Msg: " + messageText;
        
        if (flag.equalsIgnoreCase("Sent")) {
            sentMessages[sentCount] = displayLine;
            messageIDs[sentCount] = msgID;
            messageHashes[sentCount] = msgHash;
            sentCount++;
        }
        else if (flag.equalsIgnoreCase("Stored")) {
            storedMessages[storedCount] = displayLine;
            messageIDs[storedCount] = msgID;
            messageHashes[storedCount] = msgHash;
            storedCount++;
        }
        else if (flag.equalsIgnoreCase("Disregard")) {
            disregardedMessages[disregardedCount] = displayLine;
            disregardedCount++;
        }
    }
    
    // ===== OPTION a: DISPLAY ALL STORED MESSAGES =====
    public static void showAllStored() {
        if (storedCount == 0) {
            System.out.println("\nNo stored messages found.");
            return;
        }
        
        System.out.println("\n===== ALL STORED MESSAGES =====");
        for (int i = 0; i < storedCount; i++) {
            System.out.println((i+1) + ". " + storedMessages[i]);
        }
    }
    
    // ===== OPTION b: FIND LONGEST STORED MESSAGE =====
    public static String findLongest() {
        if (storedCount == 0) {
            return "No messages available";
        }
        
        String longest = storedMessages[0];
        for (int i = 1; i < storedCount; i++) {
            if (storedMessages[i].length() > longest.length()) {
                longest = storedMessages[i];
            }
        }
        return longest;
    }
    
    // ===== OPTION c: SEARCH BY MESSAGE ID =====
    public static String searchByID(String id) {
        for (int i = 0; i < storedCount; i++) {
            if (messageIDs[i].equals(id)) {
                return storedMessages[i];
            }
        }
        return "Message ID not found: " + id;
    }
    
    // ===== OPTION d: SEARCH BY RECIPIENT =====
    public static String[] searchByRecipient(String searchRec) {
        String[] temp = new String[storedCount];
        int count = 0;
        
        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i].toLowerCase().contains(searchRec.toLowerCase())) {
                temp[count] = storedMessages[i];
                count++;
            }
        }
        
        String[] result = new String[count];
        for (int i = 0; i < count; i++) {
            result[i] = temp[i];
        }
        return result;
    }
    
    // ===== OPTION e: DELETE MESSAGE BY HASH =====
    public static boolean deleteByHash(String hash) {
        for (int i = 0; i < storedCount; i++) {
            if (messageHashes[i].equals(hash)) {
                // Shift all messages left
                for (int j = i; j < storedCount - 1; j++) {
                    storedMessages[j] = storedMessages[j+1];
                    messageIDs[j] = messageIDs[j+1];
                    messageHashes[j] = messageHashes[j+1];
                }
                storedCount--;
                System.out.println("\nMessage successfully deleted!");
                return true;
            }
        }
        System.out.println("\nHash not found.");
        return false;
    }
    
    // ===== OPTION f: DISPLAY FULL REPORT =====
    public static void showFullReport() {
        if (storedCount == 0) {
            System.out.println("\nNo messages to report.");
            return;
        }
        
        System.out.println("\n===== MESSAGE REPORT =====");
        System.out.println("----------------------------------------");
        
        for (int i = 0; i < storedCount; i++) {
            String rec = getRecipient(storedMessages[i]);
            String msg = getMessage(storedMessages[i]);
            String hash = messageHashes[i];
            
            if (hash.length() > 12) {
                hash = hash.substring(0, 10) + "...";
            }
            
            System.out.println((i+1) + ". Hash: " + hash);
            System.out.println("   Recipient: " + rec);
            System.out.println("   Message: " + msg);
            System.out.println("----------------------------------------");
        }
    }
    
    // Helper: Extract recipient from message line
    private static String getRecipient(String line) {
        int start = line.indexOf("To: ");
        int end = line.indexOf(" |", start);
        if (start == -1) return "Unknown";
        return line.substring(start+4, end);
    }
    
    // Helper: Extract message from message line
    private static String getMessage(String line) {
        int start = line.indexOf("Msg: ");
        if (start == -1) return "Unknown";
        return line.substring(start+5);
    }
    
    // ===== READ JSON FILE (Source attributed) =====
    // Source: Adapted from Java NIO file reading tutorials
    public static void readJsonFile(String filename) {
        try {
            String content = new String(Files.readAllBytes(Paths.get(filename)));
            String[] lines = content.split("\n");
            
            for (int i = 0; i < lines.length; i++) {
                String line = lines[i].trim();
                
                if (line.contains("\"recipient\"")) {
                    String rec = extractValue(line);
                    
                    String msg = "";
                    for (int j = i+1; j < Math.min(i+5, lines.length); j++) {
                        if (lines[j].contains("\"message\"")) {
                            msg = extractValue(lines[j]);
                            break;
                        }
                    }
                    
                    if (!rec.isEmpty() && !msg.isEmpty()) {
                        MessagePart3 m = new MessagePart3("System", rec, msg, "Stored");
                        m.saveMessage();
                    }
                }
            }
            
            System.out.println("Loaded " + storedCount + " messages from JSON file");
            
        } catch (Exception e) {
            System.out.println("JSON file not found. Starting fresh.");
        }
    }
    
    // Helper: Extract value from JSON line
    private static String extractValue(String line) {
        int q1 = line.indexOf("\"");
        int q2 = line.indexOf("\"", q1+1);
        int q3 = line.indexOf("\"", q2+1);
        int q4 = line.indexOf("\"", q3+1);
        
        if (q3 != -1 && q4 != -1) {
            return line.substring(q3+1, q4);
        }
        return "";
    }
    
    // ===== ADD TEST DATA FROM ASSIGNMENT (Messages 1-5) =====
    public static void addTestData() {
        System.out.println("\nLoading assignment test data...");
        
        // Message 1 - Sent
        MessagePart3 msg1 = new MessagePart3("Developer", "+27834557896", "Did you get the cake?", "Sent");
        msg1.saveMessage();
        
        // Message 2 - Stored
        MessagePart3 msg2 = new MessagePart3("Developer", "+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored");
        msg2.saveMessage();
        
        // Message 3 - Disregard
        MessagePart3 msg3 = new MessagePart3("Developer", "+27834484567", "Yohoooo, I am at your gate.", "Disregard");
        msg3.saveMessage();
        
        // Message 4 - Sent
        MessagePart3 msg4 = new MessagePart3("Developer", "0838884567", "It is dinner time!", "Sent");
        msg4.saveMessage();
        
        // Message 5 - Stored
        MessagePart3 msg5 = new MessagePart3("Developer", "+27838884567", "Ok, I am leaving without you.", "Stored");
        msg5.saveMessage();
        
        System.out.println("Test data loaded!");
        System.out.println("Sent: " + sentCount + " | Stored: " + storedCount + " | Disregarded: " + disregardedCount);
    }
}

